const questions = [
  {
    text: "How do you feel when you wake up?",
    options: ["Energetic", "Tired", "Anxious", "Neutral"]
  },
  {
    text: "What best describes your current thoughts?",
    options: ["Optimistic", "Overwhelmed", "Empty", "Calm"]
  },
  {
    text: "How do you feel about people today?",
    options: ["Excited to talk", "Don't want to see anyone", "Need support", "I'm okay"]
  }
];
const moodMedia = {
  energetic: {
    text: "You're full of energy!",
    image: "https://i.imgur.com/NiZ1I2K.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
  },
  tired: {
    text: "You're feeling tired. Take it easy!",
    image: "https://i.imgur.com/YkkP0Dg.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
  },
  anxious: {
    text: "You're anxious. Try to relax.",
    image: "https://i.imgur.com/UYG45Lb.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
  },
  neutral: {
    text: "You're neutral. A balanced mood!",
    image: "https://i.imgur.com/QjSg7HE.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
  },
  optimistic: {
    text: "Optimism is powerful! Keep it up!",
    image: "https://i.imgur.com/Zh6xkgD.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3"
  },
  overwhelmed: {
    text: "You're overwhelmed. Take a break.",
    image: "https://i.imgur.com/txGZkz4.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
  },
  empty: {
    text: "Feeling empty? It's okay. This too shall pass.",
    image: "https://i.imgur.com/sTPQy1v.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3"
  },
  calm: {
    text: "You're calm and centered. Stay present.",
    image: "https://i.imgur.com/vd6zkgB.jpg",
    audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3"
  }
};
let current = 0;
let moodCount = {};
window.onload = () => {
  setTimeout(() => {
    document.getElementById('loader').style.display = 'none';
    document.getElementById('quizContainer').style.display = 'block';
    showQuestion();
  }, 1000);
};
function showQuestion() {
  const q = questions[current];
  document.getElementById('question').textContent = q.text;
  const answersDiv = document.getElementById('answers');
  answersDiv.innerHTML = '';
  q.options.forEach(option => {
    const btn = document.createElement('button');
    btn.textContent = option;
    btn.onclick = () => selectAnswer(option.toLowerCase());
    answersDiv.appendChild(btn);
  });
}
function selectAnswer(answer) {
  moodCount[answer] = (moodCount[answer] || 0) + 1;
  current++;
  if (current < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}
function showResult() {
  const resultDiv = document.getElementById('result');
  const sorted = Object.entries(moodCount).sort((a, b) => b[1] - a[1]);
  const topMood = sorted[0][0];
  const mood = moodMedia[topMood];
  resultDiv.innerHTML = `
    <p>${mood.text}</p>
    <img src="${mood.image}" alt="Mood Image" />
    <audio controls>
      <source src="${mood.audio}" type="audio/mpeg">
      Your browser does not support the audio tag.
    </audio>
  `;
  document.getElementById('question').style.display = 'none';
  document.getElementById('answers').style.display = 'none';
  document.getElementById('restartBtn').style.display = 'inline-block';
  localStorage.setItem("lastMoodMateResult", JSON.stringify({ mood: topMood, time: Date.now() }));
}
function restartQuiz() {
  current = 0;
  moodCount = {};
  document.getElementById('result').innerHTML = '';
  document.getElementById('question').style.display = 'block';
  document.getElementById('answers').style.display = 'block';
  document.getElementById('restartBtn').style.display = 'none';
  showQuestion();
}
